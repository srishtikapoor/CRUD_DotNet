﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Movie_List.Data;
using Movie_List.Models;

namespace Movie_List.Controllers
{
    public class MovieController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public static List<Information> obj = MovieData.GetData();
        public IActionResult MovieList()
        {
            // SportsData obj = new SportsData();
            return View(obj);
        }

        public IActionResult SearchById(int id)
        {
            var movie = MovieData.GetAdd(id);
            return PartialView("FilteredMoviePartial", movie);
        }
        public IActionResult AddMovie()
        {
            
            return View();
        }
        [HttpPost]
        public IActionResult InsertMovie(Information info)
        {
            obj.Add(info);

            return PartialView("ListOfMoviesPartial", obj);
        }

        public IActionResult DeleteMovie(Information information)
        {
            Information findInfo = obj.Find(x => x.MovieId == information.MovieId);
            obj.Remove(findInfo);
            return PartialView("ListOfMoviesPartial", obj);
        }
        
        [HttpPost]  
        public IActionResult Add(int MovieId, string MovieName, string ReleaseYear, string Genre)
        {
            var movie = MovieData.GAdd(MovieId, MovieName, ReleaseYear, Genre);
            return PartialView("FilteredMoviePartial", movie);
      
        }
    }

}